//
//  ContentView.swift
//  PickerView_withTag
//
//  Created by Bonnie Ryan on 2025-02-03.
//

import SwiftUI

struct ContentView: View {
    @State private var selection = "Apple"
    let options = ["Apple", "Banana", "Cherry"]

    var body: some View {
        VStack {
            Picker("Select a fruit", selection: $selection) {
                ForEach(options, id: \.self) {
                  fruit in
                    Text(fruit).tag(fruit)
                }
            }
            .pickerStyle(SegmentedPickerStyle()) // Changes picker style
            .padding()
            .onChange(of: selection) { oldValue, newValue in
                print("Debug: User changed selection from \(oldValue) to \(newValue)")
            }

            Text("You selected: \(selection)")
                .font(.largeTitle)
                .foregroundColor(getFruitColor(selection))
                .padding()
        }
    }

    func getFruitColor(_ fruit: String) -> Color {
        switch fruit {
        case "Apple": return  .red
          
        case "Banana": return .yellow
        case "Cherry": return .purple
        default: return .black
        }
    }
}



#Preview {
    ContentView()
}
