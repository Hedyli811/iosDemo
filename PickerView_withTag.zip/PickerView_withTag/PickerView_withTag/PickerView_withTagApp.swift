//
//  PickerView_withTagApp.swift
//  PickerView_withTag
//
//  Created by Bonnie Ryan on 2025-02-03.
//

import SwiftUI

@main
struct PickerView_withTagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
