//
//  PaintLifeApp.swift
//  PaintLife
//
//  Created by LI, Hedy on 2025-02-11.
//

import SwiftUI

@main
struct PaintLifeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
